import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.productContainer}>
        <TouchableOpacity style={styles.touchable01}>
          <Text style={styles.text}>DONATA SZOMBATHELYI</Text>
          <Text style={styles.text}>univ. bacc. informatol.</Text>
        </TouchableOpacity>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable02}>
          <Text style={styles.text}>O MENI</Text>
        </TouchableOpacity>
        <Text>
          24-godisnja studentica na FFOS-u, ljubiteljica vector art-a, grafickog
          dizajna i tehnologije opcenito.
        </Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable03}>
          <Text style={styles.text}>OSOBNI PODACI</Text>
        </TouchableOpacity>
        <Text>Datum rodenja: 20.04.1998.</Text>
        <Text>E-mail: donnata2015@gmail.com</Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable04}>
          <Text style={styles.text}>OBRAZOVANJE</Text>
        </TouchableOpacity>
        <Text>
          -Diplomski studij nakladnistva i informacijskih tehnologija na FFOS-u
          (2021.- )
        </Text>
        <Text>
          -Preddiplomski studij informatologije na FFOS-u (2017.-2021.)
        </Text>
        <Text>-II. gimnazija Osijek (2013.-2017.)</Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable05}>
          <Text style={styles.text}>DODATNO OBRAZOVANJE</Text>
        </TouchableOpacity>

        <Text>-Java</Text>
        <Text>-Kotlin</Text>
        <Text>-SQL</Text>
        <Text>-PHP</Text>
        <Text>-Foundations of User Experience (UX) Design</Text>
        <Text>-Build Wireframes and Low-Fidelity Prototypes</Text>
        <Text>-Start the UX Design Process: Empathize, Define, and Ideate</Text>
        <Text>-CSS</Text>
        <Text>-HTML</Text>
        <Text>-Responsive Web Design</Text>
        <Text>-UI / UX Design Specialization</Text>
        <Text>-Web Design: Wireframes to Prototypes</Text>
        <Text>-Web Design: Strategy and Information Architecture</Text>
        <Text>-UX Design Fundamentals</Text>
        <Text>-Visual Elements of User Interface Design</Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable06}>
          <Text style={styles.text}>OSOBNE VJESTINE</Text>
        </TouchableOpacity>
        <Text>-Engleski jezik (C1) </Text>
        <Text>-Njemacki jezik (B1) </Text>
        <Text>-Vozacka dozvola B kategorije</Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable07}>
          <Text style={styles.text}>DIGITALNE VJESTINE</Text>
        </TouchableOpacity>
        <Text>-Osnovno poznavanje Java, Kotlin i PHP programskog jezika</Text>
        <Text>-Osnovno poznavanje SQL-a I React Native-a</Text>
        <Text>-Dobro poznavanje HTML-a i CSS-a </Text>
        <Text>
          -Dobro upravljanje integriranim razvojnim okruzenjima - Sublime Text,
          Visual Studio Code, NetBeans
        </Text>
        <Text>
          -Dobro upravljanje bazama podataka - MariaDB (uz koristenje
          DBeaver-a), MySQL
        </Text>
        <Text>
          -Dobro upravljanje softverima za uredivanje fotografija - Adobe
          Photoshop, Adobe Illustrator, Adobe InDesign, Canva, Ribbet, Pixlr,
          PicMonkey
        </Text>
        <Text>
          -Dobro upravljanje softverima koji se odnose na UI dizajn - Figma,
          inVision, Marvel, JustInMind, Adobe XD
        </Text>
      </View>

      <View>
        <TouchableOpacity style={styles.touchable08}>
          <Text style={styles.text}>ISKUSTVO</Text>
        </TouchableOpacity>
        <Text>
          -Listopad, 2022 - volontiranje na IT konferenciji The Geek Gathering
          (6.-7.10.)
        </Text>
        <Text>
          -Listopad, 2022 - izlagaCica na studentskoj konferenciji InfoDASKA
          (3.-4.10.)
        </Text>
        <Text>-Rujan, 2022 - sudionik na IT konferenciji KulenDayz (3.9.)</Text>
        <Text>
          -Lipanj, 2022. - Srpanj, 2022. - dizajn praksa u tvrtci Factory{' '}
        </Text>
        <Text>
          -Lipanj, 2022. - izlagaCica na simpoziju RED 2022 na Ekonomskom
          fakultetu u Osijeku - izlaganje znanstvenog rada na temu "Cyber
          security awareness of Croatian students and personal data protection"
          (10.6.)
        </Text>
        <Text>
          -Travanj, 2022. - izlagaCica postera na konferenciji SRCE - Dani
          e-infrastrukture u Zagrebu (6.4.)
        </Text>
        <Text>
          -Rujan, 2021. - predavaCica na projektu "Tjedan zabranjenih knjiga"
          (27.9.)
        </Text>
        <Text>
          -Studeni, 2019. - sijeCanj, 2020. - studentska praksa u Muzeju
          likovnih umjetnosti u Osijeku
        </Text>
        <Text>
          -Ozujak, 2019. - svibanj, 2019. - studentska praksa u Muzeju Slavonije
          Osijek
        </Text>
        <Text>
          -Travanj, 2018. - lipanj, 2018. - studentska praksa u II. gimnaziji
          Osijek
        </Text>
        <Text>
          -Sijecanj, 2018. - volontiranje u Muzeju Slavonije Osijek (Noc muzeja
          - 26.1.)
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    //  justifyContent: 'center',

    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  productContainer: {
    width: '100%',
    alignItems: 'center',
  },

  touchable01: {
    width: '100%',
    height: '80%',
    padding: 15,
    margin: 10,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable02: {
    width: '100%',
    height: '40%',
    padding: 10,
    marginTop: 15,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable03: {
    width: '100%',
    height: '40%',
    padding: 10,
    marginTop: 25,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable04: {
    width: '100%',
    height: '30%',
    padding: 15,
    marginTop: 25,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable05: {
    width: '100%',
    height: '12%',
    padding: 15,
    marginTop: 25,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable06: {
    width: '100%',
    height: '45%',
    padding: 15,
    marginTop: 25,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable07: {
    width: '100%',
    height: '15%',
    padding: 20,
    marginTop: 35,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  touchable08: {
    width: '100%',
    height: '10%',
    padding: 20,
    marginTop: 25,
    marginBottom: 5,
    textAlign: 'center',
    backgroundColor: '#A0DE7C',
  },

  text: {
    textAlign: 'center',
  },
});
